<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>HTML email template</title>
    <style>
        <!-- The css code goes here
        -->
    </style>
</head>

<body>
    <div class="page">
        <h1>Thank you for your purchase <?php echo @$name; ?> </h1>

        <!-- More content here -->

        <footer>
            <a href="https://google.com">Hyperlink</a> |
            <a href="https://digitalfox-tutoroals.com">Hyperlink</a> |
            <a href="">Hyperlink</a> |
            <a href="">Hyperlink</a>
        </footer>
    </div>
</body>

</html>
